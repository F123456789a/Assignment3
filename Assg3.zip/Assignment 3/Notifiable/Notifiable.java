package Notifiable;

public interface Notifiable {
    void send(String message);
}