package SMSNotification;

import Notifiable.Notifiable;

public class SMSNotification implements Notifiable {
    @Override
    public void send(String message) {
        System.out.println("Sending SMS: " + message);
    }
}
