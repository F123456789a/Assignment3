public class ChatClient {
    private String userId;
    private boolean isDoctor;
    private ChatServer server;

    public ChatClient(String userId, boolean isDoctor, ChatServer server) {
        this.userId = userId;
        this.isDoctor = isDoctor;
        this.server = server;
        server.registerClient(this);
    }

    public void sendMessage(String message) {
        String formattedMessage = String.format("[%s]: %s", userId, message);
        server.broadcastMessage(formattedMessage, this);
    }

    public void receiveMessage(String message) {
        System.out.println(userId + " received: " + message);
    }
}