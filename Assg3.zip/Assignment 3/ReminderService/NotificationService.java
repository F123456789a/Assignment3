package ReminderService;

import EmailNotification.EmailNotification;
import Notifiable.Notifiable;
import SMSNotification.SMSNotification;

public class NotificationService {
    private Notifiable emailNotifier;
    private Notifiable smsNotifier;

    public NotificationService() {
        this.emailNotifier =  new EmailNotification();
        this.smsNotifier = new SMSNotification();
    }

    public void sendAlert(String message) {
        emailNotifier.send(message);
        smsNotifier.send(message);
    }

    public void sendReminder(String message) {
        emailNotifier.send(message);
    }
}