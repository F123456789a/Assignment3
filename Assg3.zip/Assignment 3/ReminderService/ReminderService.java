package ReminderService;

import Notifiable.Notifiable;

public class ReminderService {
    private NotificationService notificationService;

    public ReminderService() {
        this.notificationService = new NotificationService();
    }

    public void sendAppointmentReminder(String patientId, String doctorId, String dateTime) {
        String message = String.format("Reminder: You have an appointment with Dr. %s on %s", 
                                     doctorId, dateTime);
         notificationService.sendReminder(message);
    }

    public void sendMedicationReminder(String patientId, String medication, String dosage, String time) {
        String message = String.format("Reminder: Take %s of %s at %s", 
                                     dosage, medication, time);
        notificationService.sendReminder(message);
    }
}