import ReminderService.ReminderService;
import VideoCall.VideoCall;
import java.util.Scanner;

public class RPMSDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            // Displaying the menu
            System.out.println("Welcome to the Hospital Services System");
            System.out.println("Please choose a service:");
            System.out.println("1. Emergency Alert System");
            System.out.println("2. Panic Button");
            System.out.println("3. Chat & Video Consultation");
            System.out.println("4. Notifications & Reminders");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:
                    // Emergency Alert System
                    System.out.println("Emergency Alert System:");
                    System.out.print("Enter Alert Type (e.g., HeartRate/BloodPressure): ");
                    String alertType = scanner.nextLine();
                    System.out.print("Enter Patient ID: ");
                    String patientId = scanner.nextLine();
                    System.out.print("Enter Alert Value: ");
                    int alertValue = scanner.nextInt();
                    scanner.nextLine();  // Consume the newline character

                    EmergencyAlert alert = new EmergencyAlert(patientId, alertType, alertValue);
                    System.out.println("Alert created: " + alert);
                    break;

                case 2:
                    // Panic Button
                    System.out.println("Panic Button:");
                    System.out.print("Enter Patient ID to activate Panic Button: ");
                    String panicPatientId = scanner.nextLine();
                    PanicButton panicButton = new PanicButton(panicPatientId);
                    panicButton.press();
                    break;

                case 3:
                    // Chat & Video Consultation
                    System.out.println("Chat & Video Consultation:");
                    System.out.print("Enter Doctor ID: ");
                    String doctorId = scanner.nextLine();
                    System.out.print("Is the user a doctor (true/false)? ");
                    boolean isDoctor = scanner.nextBoolean();
                    scanner.nextLine();  // Consume the newline character
                    ChatServer chatServer = new ChatServer();
                    ChatClient doctor = new ChatClient(doctorId, isDoctor, chatServer);

                    System.out.print("Enter Patient ID: ");
                    String patientIdForChat = scanner.nextLine();
                    ChatClient patient = new ChatClient(patientIdForChat, false, chatServer);

                    System.out.print("Enter Message to send to Doctor: ");
                    String message = scanner.nextLine();
                    doctor.sendMessage(message);

                    System.out.println("Starting Video Call...");
                    System.out.print("Enter Patient ID for the video call: ");
                    String videoPatientId = scanner.nextLine();
                    System.out.print("Enter Doctor ID for the video call: ");
                    String videoDoctorId = scanner.nextLine();
                    VideoCall consultation = new VideoCall(videoPatientId, videoDoctorId);
                    consultation.startCall();
                    break;

                case 4:
                    // Notifications & Reminders
                    System.out.println("Notifications & Reminders:");
                    System.out.print("Enter Patient ID for Reminder: ");
                    String reminderPatientId = scanner.nextLine();
                    System.out.print("Enter Name of Person for Reminder: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Appointment Date and Time (e.g., '2023-11-15 10:00 AM'): ");
                    String appointmentTime = scanner.nextLine();
                    ReminderService reminderService = new ReminderService();
                    reminderService.sendAppointmentReminder(reminderPatientId, name, appointmentTime);

                    System.out.print("Enter Medication Name (e.g., 'Ibuprofen'): ");
                    String medication = scanner.nextLine();
                    System.out.print("Enter Medication Dosage (e.g., '300mg'): ");
                    String dosage = scanner.nextLine();
                    System.out.print("Enter Time (e.g., 'Before lunch'): ");
                    String time = scanner.nextLine();
                    reminderService.sendMedicationReminder(reminderPatientId, medication, dosage, time);
                    break;

                case 5:
                    // Exit the program
                    running = false;
                    System.out.println("Exiting the system. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}


