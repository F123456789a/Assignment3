package VideoCall;

public class VideoCall {
    private String patientId;
    private String doctorId;
    private String meetingLink;

    public VideoCall(String patientId, String doctorId) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        generateMeetingLink();
    }

    private void generateMeetingLink() {
        this.meetingLink = "https://videocall.rpms.com/" + 
                          patientId + "-" + doctorId + "-" + 
                          System.currentTimeMillis();
    }

    public void startCall() {
        System.out.println("Starting video call between " + patientId + " and " + doctorId);
        System.out.println("Join at: " + meetingLink);
    }

    public String getMeetingLink() {
        return meetingLink;
    }
}