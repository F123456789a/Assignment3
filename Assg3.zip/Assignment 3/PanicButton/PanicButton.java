public class PanicButton {
    private String patientId;
    private NotificationService notificationService;

    public PanicButton(String patientId) {
        this.patientId = patientId;
        this.notificationService = new NotificationService();
    }

    public void press() {
        String message = "PANIC BUTTON ACTIVATED by patient: " + patientId;
        notificationService.sendAlert(message);
    }
}