public class EmergencyAlert {
    private String patientId;
    private String alertType;
    private double vitalValue;
    private boolean isCritical;
    private NotificationService notificationService;

    public EmergencyAlert(String patientId, String alertType, double vitalValue) {
        this.patientId = patientId;
        this.alertType = alertType;
        this.vitalValue = vitalValue;
        this.notificationService = new NotificationService();
        checkCriticalThreshold();
    }

    private void checkCriticalThreshold() {
        switch (alertType.toLowerCase()) {
            case "heartrate":
                isCritical = (vitalValue < 60 || vitalValue > 100);
                break;
            case "bloodpressure":
                isCritical = (vitalValue > 140);
                break;
            case "temperature":
                isCritical = (vitalValue > 38.5);
                break;
            default:
                isCritical = false;
        }

        if (isCritical) {
            triggerAlert();
        }
    }

    private void triggerAlert() {
        String message = String.format("CRITICAL ALERT for patient %s: %s is at %.2f", 
                                     patientId, alertType, vitalValue);
        notificationService.sendAlert(message);
    }

    public boolean isCritical() {
        return isCritical;
    }
}