import java.util.ArrayList;
import java.util.List;

public class ChatServer {
    private List<String> messages;
    private List<ChatClient> clients;

    public ChatServer() {
        this.messages = new ArrayList<>();
        this.clients = new ArrayList<>();
    }

    public void registerClient(ChatClient client) {
        clients.add(client);
    }

    public void broadcastMessage(String message, ChatClient sender) {
        messages.add(message);
        for (ChatClient client : clients) {
            if (client != sender) {
                client.receiveMessage(message);
            }
        }
    }

    public List<String> getMessageHistory() {
        return new ArrayList<>(messages);
    }
}