package EmailNotification;

import Notifiable.Notifiable;

public class EmailNotification implements Notifiable {
    @Override
    public void send(String message) {
        System.out.println("Sending email: " + message);
    }
}